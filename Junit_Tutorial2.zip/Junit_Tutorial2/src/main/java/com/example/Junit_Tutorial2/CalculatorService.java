package com.example.Junit_Tutorial2;

import org.springframework.stereotype.Service;
@Service
public class CalculatorService {
    public int add(int a, int b) {
        return a + b;
    }
    public int subtract(int a, int b) {
        int result = a - b;
        if (result < 0) {
            return 0;
        }
        return result;
    }
    public int multiply(int a, int b) {
        return a * b;
    }
    public double divide(int dividend, int divisor) {
        if (divisor == 0) {
            throw new IllegalArgumentException("Cannot divide by zero!");
        }
        return (double) dividend / divisor;
    }
}