package com.example.Junit_Tutorial2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunitTutorial2Application {

	public static void main(String[] args) {
		SpringApplication.run(JunitTutorial2Application.class, args);
	}

}
