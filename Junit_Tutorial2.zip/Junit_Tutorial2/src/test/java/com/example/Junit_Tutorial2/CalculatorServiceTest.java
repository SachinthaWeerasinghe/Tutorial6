package com.example.Junit_Tutorial2;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
public class CalculatorServiceTest {
    private CalculatorService calculatorService;
    @BeforeEach
    public void setUp() {
        calculatorService = new CalculatorService();
    }
    @Test
    public void testAdd() {
        Assertions.assertEquals(5, calculatorService.add(2, 3));
    }
    @Test
    public void testSubtract() {
        // Testing positive result
        Assertions.assertEquals(3, calculatorService.subtract(6, 3));
        // Testing negative result
        Assertions.assertEquals(0, calculatorService.subtract(2, 5));
    }
    @Test
    public void testMultiply() {
        Assertions.assertEquals(12, calculatorService.multiply(4, 3));
    }
    @Test
    public void testDivide() {
        Assertions.assertEquals(4.0, calculatorService.divide(12, 3));
    }
    @Test
    public void testDivideByZero() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            calculatorService.divide(10, 0);
        });
    }
}