package com.example.Junit_Tutorial2;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
public class GraderTest {
    @Test
    public void testGradeA() {
        Assertions.assertEquals("A", Grader.grade(95));
        Assertions.assertEquals("A", Grader.grade(90));
    }
    @Test
    public void testGradeB() {
        Assertions.assertEquals("B", Grader.grade(85));
        Assertions.assertEquals("B", Grader.grade(80));
    }
    @Test
    public void testGradeC() {
        Assertions.assertEquals("C", Grader.grade(75));
        Assertions.assertEquals("C", Grader.grade(70));
    }
    @Test
    public void testGradeD() {
        Assertions.assertEquals("D", Grader.grade(65));
        Assertions.assertEquals("D", Grader.grade(60));
    }
    @Test
    public void testGradeF() {
        Assertions.assertEquals("F", Grader.grade(55));
        Assertions.assertEquals("F", Grader.grade(0));
    }
    @Test
    public void testInvalidScore() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Grader.grade(-5);
        });
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            Grader.grade(105);
        });
    }
}
